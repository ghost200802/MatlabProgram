close all;
clear all;
dth=0.0001;
th_min=fix(32*pi/180/dth)*dth;
th_max=fix(34*pi/180/dth)*dth;
th=th_min:dth:th_max;

for i=1:(th_max-th_min)/dth+1
    RASR=Caculate_RASR(th(i))
end
 
plot(th,RASR)