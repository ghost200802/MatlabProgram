function Analysis
%ANALYSIS Summary of this function goes here
%   Detailed explanation goes here
PRF=1495;
raw_data = Raw_Data(PRF);
f_data=fft(raw_data);
f_data=fftshift(f_data);

figure(1)
plot(abs((f_data)))


PRF=1800;
raw_data = Raw_Data(PRF);
f_data=fft(raw_data);
f_data=fftshift(f_data);

figure(2)
plot(abs((f_data)))

end

