function raw_data = Raw_Data(PRF)
%Raw_data Summary of this function goes here
%   Detailed explanation goes here
[ Vs,F0,H,Br,La,N,daz,c ] = Parameters();

daz=daz*1495/PRF;
PRF=1495;
PRT=1/PRF;

Lamda=c/F0;

j_max=500;

raw_data=zeros(1,(j_max*2+1)*3);

for i=1:N
    for k=1:2*j_max+1
        raw_data((k-1)*3+i) = exp(-j*2*pi*Vs^2/Lamda/H*((k-(j_max+1))*PRT-((N+1)/2-i)*daz/2/Vs)^2);
    end
end

end

