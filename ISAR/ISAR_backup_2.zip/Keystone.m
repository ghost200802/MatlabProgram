function [ output_signal] = Keystone( input_signal )
%KEYSTONE Summary of this function goes here
%   Detailed explanation goes here

output_signal = input_signal;
end

