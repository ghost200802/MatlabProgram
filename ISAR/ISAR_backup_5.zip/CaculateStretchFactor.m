function K = CaculateStretchFactor( ReferenceSignal,Signal )
%CACULATESTRETCHFACTOR Summary of this function goes here
%   Detailed explanation goes here
LowerRange = 0.5;
UpperRange = 2;
Accuracy = 0.002;
sz = 5;
sigma = 1;
InterpolationFactor =5;

ReferenceSignal = Interpolation(ReferenceSignal,InterpolationFactor);
Signal = Interpolation(Signal,InterpolationFactor);

Entropy = zeros(1,(UpperRange-LowerRange)/Accuracy+1);

ReferenceSignal = abs(ReferenceSignal);
ReferenceSignal = ReferenceSignal/sum(sum(ReferenceSignal));
Signal = abs(Signal);
Signal = Signal/sum(sum(Signal));

h = fspecial('gaussian',[sz sz],sigma);%����һ��3*3ģ��ĸ�˹�˲���
h = double(h);
ReferenceSignal = imfilter(ReferenceSignal,h,'replicate');
Signal = imfilter(Signal,h,'replicate');

[~,Row] = size(ReferenceSignal);

m = 1;
for Factor = LowerRange:Accuracy:1
    ReferenceSignalCaculate = Stretch(ReferenceSignal,1/Factor);  
    U = abs(Signal-ReferenceSignalCaculate);
    %U = U/sum(sum(U));
    %close all;
    %figure,imagesc(U),colormap(gray)
    Entropy(m) = sum(sum((U.^2)));
    %Entropy(m) = (-1)*sum(U(U~=0).*log(U(U~=0)));
    %Entropy(m)
    m = m+1;    
end
for Factor = 1+Accuracy:Accuracy:UpperRange
    SignalCaculate = Stretch(Signal,Factor); 
    U = abs(SignalCaculate-ReferenceSignal);
    %U = U/sum(sum(U));
    %close all;
    %figure,imagesc(U),colormap(gray)
    Entropy(m) = sum(sum((U.^2)));
    %Entropy(m) = (-1)*sum(U(U~=0).*log(U(U~=0)));
    %Entropy(m)
    m = m+1;
end

figure,plot(Entropy);

[~,col] = find(Entropy == min(min(Entropy)));
col = col(1);
K = LowerRange+col*Accuracy;




%{
%ReferenceSignal = (ReferenceSignal>Threshold*(max(max(ReferenceSignal))));
%Signal = (Signal>Threshold*(max(max(Signal))));
ReferenceSignal = exp(ReferenceSignal+0.001);
Signal = exp(ReferenceSignal+0.001);

ReferenceLeftWeight = sum(sum(ReferenceSignal(1:col_left_R,:).*((col_left_R:-1:1).'*ones(1,row_R))))/(col_left_R*row_R);
ReferenceRightWeight = sum(sum(ReferenceSignal(col_left_R+1:end,:).*((col_right_R:-1:1).'*ones(1,row_R))))/(col_right_R*row_R);

LeftWeight = sum(sum(Signal(1:col_left,:).*((col_left:-1:1).'*ones(1,row))))/(col_left*row);
RightWeight = sum(sum(Signal(col_left+1:end,:).*((col_right:-1:1).'*ones(1,row_R))))/(col_right*row_R);

K = 0.5*(LeftWeight/col_left)/(ReferenceLeftWeight/col_left_R)+0.5*(RightWeight/col_right)/(ReferenceRightWeight/col_right_R);
%}


end

