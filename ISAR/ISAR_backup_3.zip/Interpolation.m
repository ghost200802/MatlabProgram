function [ output_signal ] = Interpolation( input_signal,K_interpolation )
%INTERPOLATION Summary of this function goes here
%   Detailed explanation goes here
%%
%{
%�������ź�ͨ��Ƶ��0�ķ�������K_interpolation���Ĳ�ֵ
[col,row] =size(input_signal);
output_signal = zeros(col*K_interpolation,row);
input_signal = fft(input_signal);
output_signal(1:col,1:row) = input_signal;
output_signal = ifft(output_signal);
%}
%%
[col,row] =size(input_signal);
[X,Y] = meshgrid(1:row,1:1/K_interpolation:col);
output_signal = interp2(input_signal,X,Y,'spline');
end

