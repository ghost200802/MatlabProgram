function L = TargetMove( L0,T )
%TARGETMOVE Summary of this function goes here
%   Detailed explanation goes here

a = 0;          %Ŀ����ٶ�
L = L0+0.5*a*T^2;

%v = 0.5;          %Ŀ���ٶ�
%L = L0+v*T;

%L = L0;
end

