function  SubAperture
%SUBAPERTURE Summary of this function goes here
%   Detailed explanation goes here
close all;
clear all;
clc;

N_Aperture = 4;

load('ImagingResult.mat');
figure,imagesc(abs(signal_process)/max(max(abs(signal_process)))),colormap(gray);
[Col,Row] = size(signal_process);
ifft_signal_process = ifft(signal_process);


ApertureLength = ceil(Col/N_Aperture);
LastMismatch = N_Aperture*ApertureLength-Col;
MismatchLeft = floor(LastMismatch/2);
MismatchRight = ApertureLength-(LastMismatch-MismatchLeft);

K0 = 0.0125;


signal_output = zeros(0,Row);
signal_process = zeros(ApertureLength,Row,N_Aperture);

for m = 1:N_Aperture
    if(m~=N_Aperture)
        signal_process(:,:,m) = fft(ifft_signal_process((m-1)*ApertureLength+1:m*ApertureLength,:));
    else
        signal_process(MismatchLeft+1:MismatchRight,:,m) = fft(ifft_signal_process((m-1)*ApertureLength+1:end,:));
    end
end

K = ones(1,N_Aperture);
X = zeros(1,N_Aperture);
%%{
for m = 2:N_Aperture
    %K(m) = 1+(2*m-1)*K0;
    [K(m),X(m)] = CaculateFactor(signal_process(:,:,1),signal_process(:,:,m));

end
%}
%{
for m = 1:N_Aperture
   K(m) = 1+K0*(2*m-1); 
end
%}

K_min = min(K);     %��֤����K������1
K = K/K_min;

for m = 1:N_Aperture    
    SignalStretched = Stretch(signal_process(:,:,m),K(m));
    
    TranslationInterpolation = (1:ApertureLength)+X(m);       
    TranslationInterpolationLeft = ceil(-1*min(X(m),0));
    TranslationInterpolationRight = ceil(max(X(m),0));
    TranslationInterpolation = TranslationInterpolation(TranslationInterpolationLeft+1:ApertureLength-TranslationInterpolationRight);
    SignalTranslated = complex(spline(1:ApertureLength,real(SignalStretched.'),TranslationInterpolation).',spline(1:ApertureLength,imag(SignalStretched.'),TranslationInterpolation).');
    SignalTranslated = [zeros(TranslationInterpolationLeft,Row);SignalTranslated;zeros(TranslationInterpolationRight,Row)];
    
    figure,imagesc(abs(SignalTranslated)/max(max(abs(SignalTranslated)))),colormap(gray);
    signal_output = [signal_output;ifft(SignalTranslated)];
end

signal_output = fft(signal_output);
figure,contour(abs(signal_output)/max(max(abs(signal_output)))),colormap(jet);
figure,imagesc(abs(signal_output)/max(max(abs(signal_output)))),colormap(gray);

end

