function [ OutputSignal ] = Stretch( InputSignal,K )
%STRETCH Summary of this function goes here
%   Detailed explanation goes here
%������Ϊ�����K>=1,��ѡȡ������¿��Ա������е���Ϣ
[InputCol,row] = size(InputSignal);

OutputSignal = complex(spline(1:InputCol,real(InputSignal.'),1:K:InputCol).',spline(1:InputCol,imag(InputSignal.'),1:K:InputCol).');
%OutputSignal = InputSignal(round(1:K:end),:); 

InputMid = floor(InputCol/2);
OutputMid = round(InputMid/K);
OutputEnd = size(OutputSignal,1); 
LeftZeros = InputMid-OutputMid;
RightZeros = InputCol-OutputEnd-LeftZeros;

OutputSignal = [zeros(LeftZeros,row);OutputSignal;zeros(RightZeros,row)];
OutputSignal = OutputSignal/(sum(sum(abs(OutputSignal))));

end

