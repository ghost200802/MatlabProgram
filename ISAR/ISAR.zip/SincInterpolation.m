function [ OutputSignal ] = SincInterpolation( InputSignal,InterpolationPoints,SincPoints,SincFactor )
%SINCINTERPOLATION Summary of this function goes here
%   Detailed explanation goes here
InputLength = size(InputSignal,2);          %�����InputSignal��InterpolationPoints����һά������
OutputLength = size(InterpolationPoints,2);
OutputSignal = zeros(1,OutputLength);

if(mod(SincPoints,2)==1)        %Sinc�ĵ�������Ϊż��
    SincPoints = SincPoints+1;
end

Factor = zeros(SincPoints,OutputLength);
for m = 1:SincPoints
    Factor(m,:) = mod(InterpolationPoints,1)+m-SincPoints/2-1;
end
Factor = sinc(SincFactor*Factor);

Position = floor(InterpolationPoints);
PositionLeft = Position-SincPoints/2+1;
PositionRight = Position+SincPoints/2;

for m = 1:OutputLength
    if(PositionLeft(m)<=0)
        PositionLeft(m)
        PositionLeftZeros = 1-PositionLeft(m)
        PositionLeft(m) = 1;
    else
        PositionLeftZeros = 0;
    end
    if(PositionRight(m)>InputLength)
        PositionRightZeros = PositionRight(m)-InputLength;
        PositionRight(m) = InputLength;
    else
        PositionRightZeros = 0;
    end
    PartInput = [zeros(1,PositionLeftZeros),InputSignal(PositionLeft(m):PositionRight(m)),zeros(1,PositionRightZeros)];
    
    OutputSignal(m) = PartInput*Factor(:,m);

end

