function [K,X] = CaculateFactor( ReferenceSignal,Signal )
%CACULATESTRETCHFACTOR Summary of this function goes here
%   Detailed explanation goes here
StretchLowerRange = 1;
StretchUpperRange = 1.1;
StretchAccuracy = 0.01;

TranslationLowerRange = 0;
TranslationUpperRange = 1;
TranslationAccuracy = 0.1;



Entropy = zeros(((StretchUpperRange-StretchLowerRange)/StretchAccuracy+1),((TranslationUpperRange-TranslationLowerRange)/TranslationAccuracy+1));

ReferenceSignal = abs(ReferenceSignal);
ReferenceSignal = ReferenceSignal/sum(sum(ReferenceSignal));
Signal = abs(Signal);
Signal = Signal/sum(sum(Signal));


[Col,Row] = size(ReferenceSignal);

m = 1;

for StretchFactor = StretchLowerRange:StretchAccuracy:1
    n = 1;
    for TranslationFactor = TranslationLowerRange:TranslationAccuracy:TranslationUpperRange
        
        ReferenceSignalCaculate = Stretch(ReferenceSignal,1/StretchFactor);  
        %{
        TranslationInterpolation = (1:Col)+TranslationFactor;       
        TranslationInterpolationLeft = ceil(-1*min(TranslationFactor,0));
        TranslationInterpolationRight = ceil(max(TranslationFactor,0));
        TranslationInterpolation = TranslationInterpolation(TranslationInterpolationLeft+1:Col-TranslationInterpolationRight);
        SignalCaculate = complex(spline(1:Col,real(Signal.'),TranslationInterpolation).',spline(1:Col,imag(Signal.'),TranslationInterpolation).');
        SignalCaculate = [zeros(TranslationInterpolationLeft,Row);SignalCaculate;zeros(TranslationInterpolationRight,Row)];
        %}
        %U = abs(SignalCaculate-ReferenceSignalCaculate);
        U = abs(Signal-ReferenceSignalCaculate);
        Entropy(m,n) = sum(sum((U.^2)));           
        n = n+1;
    end
    m = m+1; 
end
for StretchFactor = 1+StretchAccuracy:StretchAccuracy:StretchUpperRange
    n = 1;
    for TranslationFactor = TranslationLowerRange:TranslationAccuracy:TranslationUpperRange
        SignalCaculate = Stretch(Signal,StretchFactor); 
        %{
        TranslationInterpolation = (1:Col)+TranslationFactor;       
        TranslationInterpolationLeft = ceil(-1*min(TranslationFactor,0));
        TranslationInterpolationRight = ceil(max(TranslationFactor,0));
        TranslationInterpolation = TranslationInterpolation(TranslationInterpolationLeft+1:Col-TranslationInterpolationRight);
        SignalCaculate = complex(spline(1:Col,real(SignalCaculate.'),TranslationInterpolation).',spline(1:Col,imag(SignalCaculate.'),TranslationInterpolation).');
        SignalCaculate = [zeros(TranslationInterpolationLeft,Row);SignalCaculate;zeros(TranslationInterpolationRight,Row)];
        %}
        U = abs(SignalCaculate-ReferenceSignal);
        Entropy(m,n) = sum(sum((U.^2)));
        n = n+1;
    end
    m = m+1;
end


figure,imagesc(Entropy/max(max(Entropy))),colormap(gray);

[col,row] = find(Entropy == min(min(Entropy)));
col = col(1);

row = row(1);
K = StretchLowerRange+(col-1)*StretchAccuracy;
X = TranslationLowerRange+(row-1)*TranslationAccuracy;

end

