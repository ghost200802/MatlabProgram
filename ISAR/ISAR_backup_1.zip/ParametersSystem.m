function [ output_args ] = ParametersSystem( input_args )
%PARAMETERSSYSTEM Summary of this function goes here
%   Detailed explanation goes here


end

